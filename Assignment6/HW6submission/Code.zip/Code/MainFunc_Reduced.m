getSIFTfeature;
Clustering;
GetTrainingHistogram;
reducedDataSet;